#!/bin/bash
#20170711
#sql 更新



#前提： 
#               1.压缩文件的名字去掉后缀后，就是解压后的文件夹名称
#               2.解压后的文件夹中以beam结尾的都是要更新的模块
#               3.压缩文件的类型是tar.gz并以.tar.gz结尾
dirname=$1
filename=$2
servername=$3
dbport=$4
regionid=$5
worldid=$6

DBdate=`date +%Y-%m-%d-%H%M`;
DBuser='root'           
DBpasswd='b6[aJ*NK#q)s40)M' 

locale_backup_dir='/data/backup/db_backup';
Mysqldump=/usr/local/mysql/bin/mysqldump ;
Mysql=/usr/local/mysql/bin/mysql;
opts='--default-character-set=utf8 -R -h 127.0.0.1'
DBname="luna_gamedata_${regionid}_${worldid} luna_gamelog_${regionid}_${worldid}"
dbfilename="${servername}_luna_game_${regionid}_${worldid}"
tarfile="$locale_backup_dir/${dbfilename}_$DBdate.tar.gz"
sqlfile="$locale_backup_dir/${dbfilename}_$DBdate.sql"

alias cp='cp'
PATH=/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin
export PATH



function checkresult
{
	logfile='/var/log/mysql_backup.log'
	if [ "$1" != '0' ]
	then
		echo "$2 $3 is error at $4 " | tee -a $logfile
		exit 2;
	fi
}

function bak {
	echo "backup luna_gamedata_${regionid}_${worldid} and luna_gamelog_${regionid}_${worldid}"
	$Mysqldump  -u $DBuser -p$DBpasswd $opts -P$dbport  --master-data=2  -B $DBname > $sqlfile
	checkresult $? mysqldump $DBname $DBdate
   	 /bin/tar -zcvf $tarfile $sqlfile
    	checkresult $? tar $sqlfile $DBdate 
	echo "luna_gamedata_${regionid}_${worldid} luna_gamelog_${regionid}_${worldid} backup success!"
	
}
function getfile {
        /bin/sh  /data/scripts/update/scripts/get-newversion_luna.sh $dirname $filename $servername
        [ $? = 1 ] && echo -e "\033[31m upload $file fail !!! \033[0m" && exit
}

function check_package_md5()
{
	filebase="/data/upload/$servername"
	cd $filebase
	#有大小区之分，先同意切换为大写，进行比较
    	package_md5sum_x=$(echo $filename | awk -F'.' '{print $NF}')
    	package_md5sum_check_x=$(md5sum $filebase/$filename|awk '{print $1}')
	package_md5sum=$(echo $package_md5sum_x | tr [a-z] [A-Z])
	package_md5sum_check=$(echo $package_md5sum_check_x | tr [a-z] [A-Z])

         
    	if [ "$package_md5sum" != "$package_md5sum_check" ] 
    		then
    	{
        	rm -f $filename
            	echo "$(date +%F_%H-%S-%M):  ERROR: md5sum of [$package_filename] does not match!"
            	exit 1
        }
    	else
    	{
        	echo "$(date +%F_%H-%S-%M):  SUCC: md5sum of [$filename] matched!" 
  	}
    	fi
}
function extractfile()
{
	cd $filebase
        tar -xzf $filename
        if [ "$?" != '0' ]
        then
                "extract $filename failed" && rm $filedir -rf && exit
        fi
}

function get_package()
{
	cd $filebase
        filedir=$(echo $filename| awk -F'.' '{print $1}')
        if [ ! -d $filedir ]
        then
                echo "$filedir not exist,please check package"
		exit 1
        fi
}

function runsql()
{
	cd $filebase/$filedir
	sqls=`ls *.sql`
	for sql in $sqls
	do
		echo "/usr/local/mysql/bin/mysql -uroot -P$dbport -h127.0.0.1 -p$passwd luna_gamedata_${regionid}_${worldid} < $sql"
		/usr/local/mysql/bin/mysql -uroot -P$dbport -h127.0.0.1 -p$DBpasswd luna_gamedata_${regionid}_${worldid} < $sql
		[ $? != 0 ] && echo $sql inport fail!! && exit
		echo import sql success!!
	done	
	
}
  if [ "$#" == 6 ] 
    then
    {
	bak
        getfile
        check_package_md5
        extractfile
        get_package
    }
    else
    {
        echo "please input correct parameter"
	echo "EX:sh import_sql.sh test luna_gamedata_20170707_v48780.tar.gz.5FAA68B6425CB2C852143F7BB8AEAF84 luna_mainland_inspection_998 2998 1 998"
	exit
    }
    fi


runsql

