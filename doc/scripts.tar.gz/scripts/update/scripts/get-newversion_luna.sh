#!/bin/bash

dirname="$1"
filename=$2
servername=$3
LocalDir=/data/upload/$servername
RemoteDir=/$dirname
#Host="123.206.82.217"
Host="106.75.139.52"
Port=21
User="luna_yanfa_upload"
Password="YY68v+t58x2TxU:Z"
Date=`date +%Y-%m-%d`

if [ $# != 3 ]
then
        echo "Usage: $0 versionname"
        echo "Example: sh $0 20130527_hotupdate.tar.gz"
        exit 1

fi

if [ ! -d $LocalDir ]
then
        mkdir $LocalDir
fi

ftp -n -i <<EOF
open $Host $Port
user $User $Password

lcd $LocalDir
cd $RemoteDir
binary
get $filename 
quit
EOF
