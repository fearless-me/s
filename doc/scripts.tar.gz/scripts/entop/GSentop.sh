cd /data/scripts/entop/entop-master && chmod +x entop
/data/scripts/entop/entop-master/entop luna_mainland_inspection_999@10.141.176.173  -name entopGS@127.0.0.1 -setcookie erlide








