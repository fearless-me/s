#!/bin/bash
#



echo $1,$2,$3,$4 >>  /tmp/hot-test.log
echo "success"
