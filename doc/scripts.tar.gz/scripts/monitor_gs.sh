#!/bin/sh
#check gs port

#set -o errexit
#set -u

servername=$1
ServerBase=/data/server/
RELEASE_HOME=$ServerBase/$servername
db_user="luna_yanfa"
db_password="g):bepfQ]9K03FZ3"
lockfile=/tmp/"$servername"_lock
IP=`curl ip.cip.cc`

function help
{

    echo -e "\033[31m which serve are you trying to operate? \033[0m"
    find $ServerBase -maxdepth 1 -type d | sed "s#$ServerBase##g"| sed '/^$/d' |grep luna

}



function check_pid 
{
Min1=$(ls -l $lockfile | awk -F " " '{print $8}' | cut -d : -f 2 )
Hou1=$(ls -l $lockfile | awk -F " " '{print $8}' | cut -d : -f 1 )
Min2=$(date | awk -F " " '{print $4}' | cut -d : -f 2)
Hou2=$(date | awk -F " " '{print $4}' | cut -d : -f 1)

if [ "$Hou1" -eq "$Hou2" ]
     then
       TM=$(expr $Min2 - $Min1)
           if [ "$TM" -ge '20' ]
           then

                rm -rf $lockfile
           else
                echo "$servername is already running check...." >> /data/log/crontab.log
                echo -e "\033[31m $servername is already running check....   \033[0m"
                exit
           fi
      else
       TM1=$(expr $Min2 + 60)
       TM2=$(expr $TM1 - $Min1)
           if [ "$TM2" -ge '20' ]
           then

                rm -rf $lockfile
           else
                echo "$servername is already running check...." >>  /data/log/crontab.log
                echo -e "\033[31m $servername is already running check....   \033[0m"
                exit
           fi
fi
}




function alarm_tool()
{
	echo $1 >> /data/log/crontab.log
        curl message.haowan123.com/sms/?group='luna'\&content="$1"
#	echo "curl message.haowan123.com/sms/?group='luna'\&content='"$1"'"
}




function check_stat(){
        
        if [ -e $lockfile ]
        then
            check_pid
        fi
        touch $lockfile
      
	monitor_dir=/data/scripts/monitor/
	monitor_file=monitor_${servername}.txt
	[ ! -d $monitor_dir ] && mkdir $monitor_dir 
	
	if [ ! -f ${monitor_dir}${monitor_file} ]
	then
		mysql -h ops-db.553.com -u$db_user -p$db_password -P3306 -e "select gameport1,gameport2,gameport_gm,gameport_recharge from luna_serverlist.configdb where servername='$servername' " 2>/dev/null >${monitor_dir}${monitor_file}
	fi
	cd $monitor_dir
        filesize=`du -sh monitor_${servername}.txt |awk -F' ' '{print $1}'`
        [ "$filesize" == 0  ] && echo "get port from yw_db fail" && rm ${monitor_dir}${monitor_file} -rf  && exit
       
        gameport1=`awk 'END{print}' ${monitor_dir}${monitor_file} |awk '{print $1}'` 
        gameport2=`awk 'END{print}' ${monitor_dir}${monitor_file} |awk '{print $2}'`
        gameport_gm=`awk 'END{print}' ${monitor_dir}${monitor_file} |awk '{print $3}'`
        gameport_recharge=`awk 'END{print}' ${monitor_dir}${monitor_file} |awk '{print $4}'`       
   
	sum=0	
	for (( i=1;i<=3;i++ ))	
	do
		netstat -lnt|grep $gameport1 |tee -a /data/log/crontab.log 
		gameport1_stat=`echo $?` 
		netstat -lnt|grep $gameport2 |tee -a /data/log/crontab.log 
		gameport2_stat=`echo $?`
		netstat -lnt|grep $gameport_gm |tee -a /data/log/crontab.log
		gameport_gm_stat=`echo $?`
                netstat -lnt|grep $gameport_recharge |tee -a /data/log/crontab.log
                gameport_recharge_stat=`echo $?`
     
                ps -ef|grep beam|grep -v 'grep'|grep "$servername" |tee -a /data/log/crontab.log
                ps_stat=`echo $?`
                
               
		
		if [ $gameport1_stat -eq 0 -a  $gameport2_stat -eq 0 -a  $gameport_gm_stat -eq 0 -a  $gameport_recharge_stat -eq 0 -a $ps_stat -eq 0 ]
		then
			let sum+=$i
		fi	
		sleep 5
	done
	
		
	#if [ $ls_stat -eq 0 -a  $worldport1_stat -eq 0 -a  $worldport2_stat -eq 0 ];then
	if [ "$sum" -ne "0" ];then
		echo "$servername running OK at `date +%Y%m%d_%H:%M:%S`" >> /data/log/crontab.log 
                echo  "$servername running OK at `date +%Y%m%d_%H:%M:%S` "
		rm -f $lockfile	
		exit 10 
	else 
		alarm_tool "$servername $IP is down at `date +%Y%m%d_%H:%M:%S`" 
                
                
	fi
}


case "$#" in
    0)
      help
       ;;
    1)
      check_stat
       ;;
    2|*)
      help
       ;;
      
esac


