#!/bin/bash
#



echo $1,$2,$3,$4 >>  /tmp/update-test.log
echo "sccss"
