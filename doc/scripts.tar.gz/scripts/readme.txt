###########################
      luna脚本说明
##############################

1. myservice.sh    ##用户停服启服，直接执行脚本可查询说明

2. monitor_gs.sh   ##用于业务监控，主要是游戏进程和4个端口，若有问题，则发送报警短信

3. update/update.py  ##用于停服更新，需要先执行上述停服脚本，停服后直接python执行可查询说明,日志在update/log/

4. hotupdate/hotupdate.py   ##用于热更，直接python执行可查询说明,日志在hotupdate/log/


