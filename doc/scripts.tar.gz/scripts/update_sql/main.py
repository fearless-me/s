#!/usr/bin/env python
#author:luodi date:2014/10/23
#descriptions:this is a exec program main.
#version:v1.0 mtime:2014/10/24

'''
Use this script to manager fanxian game servers
1. Shut down the servers
2. Start the servers
3. Check the servers
4. Other custom scripts
5. Dump the servers
6. Check the server's dump
'''

import os,subprocess
import sys,time
import threading

class Managerserver():
        def __init__(self):
                self.operlist=['hotupdate','import_sql','dump','checkdump','upgrade','addindex']
        #get your input content
        def testinput(self):
                if len(sys.argv) < 2:
                        print 'Usage:python main.py {hotupdate|import_sql|dump|checkdump|upgrade} area'
                        sys.exit(1)

                elif len(sys.argv) < 3:
                        allarea = ['mainland','app','tx','yueyu']
                        print allarea
                        sys.exit(1)
                else:
                        shellname = sys.argv[1]
                        keyword = sys.argv[2]
                        if shellname not in self.operlist:
                                print "input error!!"
                                sys.exit(1)
                return keyword,shellname

        #print help menus
        def printhelp(self):
                print """
                        |----------Help infomation---------|
                        |1.Choice one or more servers      |
                        |2.Choice All servers              |                
                        |----------------------------------|
                        """
                while True:
                        try:
                                SelectInput=int(raw_input('Please enter your choice:'))
                                break
                        except ValueError:
                                continue
                        except KeyboardInterrupt:
                                sys.exit(1)
                return SelectInput

        #import public.py module to list your input area ip list
        def _listip(self):
                keyword,shellname = self.testinput()
                f = os.popen('/usr/bin/python ./getinfo/public.py  %s '%keyword)
                list=f.readlines()
                if len(list) == 0:
                        print "Input Area Error!!! please try again"
                        sys.exit(1)
                return list

        #define action object
        def _operition(self,filename,ip,servername,mysqlport,regionid):
                keyword,shellname = self.testinput()  
                file = os.system("/bin/sh " + './script/' + shellname + ' ' + ip + ' ' + servername + ' ' + mysqlport+' '+regionid)

        #get your input choice one or more ip list
        def getinfo(self,shellname):
                servername=(raw_input("\n"))
                servername = ",".join(servername.split())
                newservers=servername.split(',')

                oldlist=self._listip()
                for item in oldlist:
                        print("item:",item)
                        newlist = item.strip('\n')
                        list = newlist.split(' ')
                        ip = list[1]
                        servername = list[0]
                        mysqlport = list[2]
                        regionid = list[3] 
                        if servername in newservers:
                                p = threading.Thread(target=self._operition,args=(shellname,ip,servername,mysqlport,regionid))
                                p.start()

        #program main function
        def multithreading(self):
                choiceid=self.printhelp()
                if choiceid == 1:
                        oldlist=self._listip()
                        keyword,shellname = self.testinput()
                        print "########################################"
                        for i in oldlist:
                                newlist = i.strip('\n')
                                list = newlist.split(' ')
                                servername = list[0]
                                ip = list[1]
                                mysqlport = list[2]
				regionid = list[3]
                                print ip,servername
                        print "########################################"
                        print "\033[32mPlease input servername,not server ip!!!\033[0m"
                        try:
                                self.getinfo(shellname)
                        except KeyboardInterrupt:
                                print "Program is quit!!!!"


                elif choiceid == 2:
                        while True:
                                try:
                                        SelectInput=raw_input('Please make sure you input is correct?(y/n):').strip()
                                        if len(SelectInput) == 0 :
                                                continue
                                        else:
                                                break
                                except ValueError:
                                        continue
                                except KeyboardInterrupt:
                                        sys.exit(1)
                        if SelectInput == "Y" or SelectInput == "y":
                                oldlist=self._listip()
                                keyword,shellname = self.testinput()
                                for i in oldlist:
                                        newlist = i.strip('\n')
                                        list = newlist.split(' ')
                                        servername = list[0]
                                        ip = list[1]
                                        mysqlport = list[2]
					regionid = list[3]
                                        p = threading.Thread(target=self._operition,args=(shellname,ip,servername,mysqlport,regionid))
                                        p.start()
                                        time.sleep(3)
                        else:
                                sys.exit(1)
                else:
                        print "select error"
                        sys.exit(1)

        def run(self):
                self._listip()
                self.multithreading()

start=Managerserver()
start.run()
