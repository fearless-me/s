#!/usr/bin/python

import re
import sys

#srcfile = 'hotupdate.sh'
srcfile = sys.argv[1]
keywords = ['filename','modules','mysqlpassword','modulename','funcname','sqlname']

def splitline(data, sep="'"):
    return data.split(sep)[1]

def matchline(pattern, data):
    m = re.match(pattern, data)
    if m is not None:
        return data

def main(srcfile):
    file = open(srcfile, 'r')
    for line in file:
        for keyword in keywords:
            retline = matchline(keyword, line)
            if retline is not None:
                ret = splitline(retline)
                print "%s ==> %s" % (keyword, ret)
    confirm()

def confirm():
    input = raw_input('if all of them are right, please input "yes":\n')
    if input != 'yes':
        print 'please reinput these content'
        sys.exit()

if __name__ == '__main__':
    main(srcfile)
