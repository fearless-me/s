#!/usr/bin/env python
#author:luodi date:2014/10/20
#descriptions:The model's update system's connection model
import MySQLdb
def Conn():
    conn=MySQLdb.connect(host='54.223.130.112',user='luna_yanfa',passwd='g):bepfQ]9K03FZ3',db='luna_serverlist',port=3306)
    cur=conn.cursor()
    return conn,cur

if __name__ == "__main__":
    pass
else:
    conn,cur=Conn()
