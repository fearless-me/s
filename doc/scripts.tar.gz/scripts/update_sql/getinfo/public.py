#!/usr/bin/env python
#author:luodi date:2014/10/20
#descritpions:use this model to get you input area infomation
#version v1.1 mtime:2014/10/20

from connection import *
import sys,os

class ServerInfo():
    def __init__(self):
        self.cur=cur
        self.conn=conn

    def Testinput(self):
        if len(sys.argv) < 2:
            print "You input is Error"
            sys.exit(1)
        else:
            input = sys.argv[1]
            return input

    def Getinfo(self):
            input = self.Testinput()
            cc=self.cur.execute('''select servername,externalip,data_port,regionid from \
            configdb where servername like '%%%s%%' and  ismerged='0' ''' % input)
            values = cur.fetchall()
            for line in values:
                print line[0],line[1],line[2],line[3]
            self.cur.close()
            self.conn.close()
aa=ServerInfo()
aa.Getinfo()
