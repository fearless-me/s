#!/bin/bash

cwd=$(dirname $0)
cd $cwd

#sh /data/scripts/monitor.sh wdsg_andr_official_31
###sh /data/scripts/monitor_gs.sh luna_mainland_inspection_999
