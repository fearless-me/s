#!/usr/bin/python
#-*- coding:utf-8 -*-

import os
import sys
import tarfile
import time
import shutil
from module.ftpconnect import *
from module.checkmd5 import *
from module.logs import *


class Update(object):

    def __init__(self):
            self.nowdate = time.strftime('%Y%m%d-%H%M%S',time.localtime(time.time()))
            self.dir = '/data/server/'
            self.ftpdir = '/data/upload/'
            self.backup = '/data/server/back/'
            self.servertype = 'gameserver'



    ###帮助信息####
    def help(self):
        if len(sys.argv) < 2:
            print '''\033[31mplease input ftp remote dir,example: 
            test
            mainland
            app  \033[0m'''        
            sys.exit(1)
        if len(sys.argv) < 3:
            print '''\033[31mplease input update packagename ,example:
            luna_gameserver_install_20170630_v47258.tar.gz.91c24425bb4fc49d881284c40dc4815a \033[0m '''
            sys.exit(1)
        if len(sys.argv) < 4:
            dirs = os.listdir(self.dir)
            for i in dirs:
                a=self.dir+i
                if os.path.isdir(a):
                    print "\033[31m %s \033[0m" %i
            sys.exit(1)
        else:
            ftpdir = os.sys.argv[1]
            packagename = os.sys.argv[2]
            servername = os.sys.argv[3]
            return ftpdir,packagename,servername
            #update(ftpdir,packagename,servername)
    
    ###下载更新包,检验md5值###
    def download_package(self,ftpdir,packagename,servername):
        a=download_files(ftpdir,packagename,servername)
        b=GetFileMd5(a[1])
        package_md5=b[0][0].lower().split('gz.')[1]
        check_md5=b[0][1]
        if package_md5 == check_md5 :
            logging.info('package md5 OK !!')
        else:
            print '\033[31mmd5 check fail && update fail \033[0m'
            print 'package md5: %s' % (package_md5)
            print 'local   md5: %s' % (check_md5)
            logging.error('package md5 check fail')
            logging.error('package md5: %s' % (package_md5))
            logging.error('local   md5: %s' % (check_md5))
            sys.exit(1)
        
    ####备份###### 
    def backupfile(self,servername):
        try:
            back_dir= self.backup + self.servertype + '_' + self.nowdate
            if os.path.exists(self.backup):
                pass
            else:
                os.mkdir(self.backup)
            beam_file=os.path.join(self.dir,servername)
            os.chdir(beam_file)
            shutil.copytree(self.servertype, back_dir)
            tar_file=self.backup + self.servertype + self.nowdate + '.tar.gz'
            tar=tarfile.open(tar_file,"w:gz")
            os.chdir(self.backup)
            for root,dir,files in os.walk(self.servertype + '_' + self.nowdate):  
                for file in files:  
                    fullpath = os.path.join(root,file)  
                    tar.add(fullpath)         
            logging.info('backup file is here : %s' % (os.path.join(self.backup,tar_file)))
            shutil.rmtree(back_dir)
        except Exception ,e:
             raise e
                        
        
    #######更新#########
    def updatefile(self,ftpdir,packagename,servername):
        try:
            self.download_package(ftpdir,packagename,servername)   ###下包
            aa=self.tar_package(packagename,servername)
            self.backupfile(servername)
            update_ebin=self.servertype + '/ebin/'
            update_dir=self.dir + servername + '/' + update_ebin
            package_dir=os.path.join(aa,packagename.split('.tar')[0])
            os.chdir(package_dir)
            if os.path.exists(update_ebin):
                for i in os.listdir(update_ebin):
                    shutil.copy(update_ebin+i,update_dir)
    
                self.diffmd5(package_dir,servername,update_ebin) 
            else:
                print '''
           \033[31m update package gameserver/ebin/ is not exist && update fail !! \033[0m
             '''
                logging.error('gameserver/ebin/ is not exist')
            sys.exit(1) 
            
        except Exception, e:
            raise e
    
    #####遍历比对更新前更新后文件md5######
    def diffmd5(self,package_dir,servername,update_ebin):
        try:
            update_dirs=self.dir + servername + '/' + update_ebin
            os.chdir(package_dir)
            code=0
            for i in os.listdir(update_ebin):
                    c=GetFileMd5(update_dirs+i)[0][1]
                    b=GetFileMd5(update_ebin+i)[0][1]
                    if b != c:
                        print "\033[31m diff mad5 error at %s && update fail !! \033[0m" %i
                        logging.error('diff mad5 error at %s' %i)
                        code=2
                        sys.exit(1)
            if code == 0:
                print ''' 
               \033[31m update success !! \033[0m 
                 '''
                logging.info('update success !!')
            
        except Exception, e:
            raise e
    
    
    #####解压更新包#####
    def tar_package(self,packagename,servername):
        try:
            tar_localpath=self.ftpdir + servername + '/'
            packagename_dir=tar_localpath + packagename
            tar=tarfile.open(packagename_dir, "r:gz")
            for ti in tar:
                tar.extract(ti, tar_localpath)
            tar.close()    
            if os.path.exists(tar_localpath+packagename.split('.tar')[0]):
                return tar_localpath
            else:
                print ''' 
                \033[31m extract package dir is not right,please give package agagin  && update fail!! \033[0m
                '''
                logging.error('extract package dir is not right,please give package agagin')
                sys.exit(1)
        except Exception, e:
            raise e
             
    
    def run(self):
                arg=self.help()
                self.updatefile(arg[0],arg[1],arg[2])

update = Update()
update.run()

